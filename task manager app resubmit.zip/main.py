# Task 25 - Task Manager Version 2.

# Create a program for a small business to
# help manage tasks assigned to each team member

# on opening the program, there is a 
# greeting message that tells the user
# what App they are using.  
print("Welcome to the Task Manager App.\n")

# use with to open file 
# use the read function to read the file
# use replace to take out new lines and 
# use the split to turn it into a list
# set valid user and password as list variables
# set login as boot False
# use for loop to itterate through list
# using the length of the list as the range
# use if divided by 2 and equal to 0
# to seperate username and password
# append valid user name and passwords respectively
# Prompt user to input username and password
# using while loop to check if login bool turns to True.
# using an if statement and in file function
# to compare username and pw
# using the if statements to notify User 
# what aspect of their login details are incorrect
# import datetime for use later in program 
from datetime import date 

with open("user.txt", "r") as f:
  file_user = f.read()
  user_file = file_user.replace("\n", ", ")
  user_f = user_file.split(", ")
  valid_user = []
  valid_password = []
  login = False
  for i in range(len(user_f)):
    if i%2 == 0:
      valid_user.append(user_f[i])
      login = False
    if i%2 != 0:
      valid_password.append(user_f[i])
      login = False

while login == False:
  username = input("Enter your username: ")
  password = input("Enter your password: ")
  if username in valid_user and password in valid_password:
    print("\nWelcome " + str(username))
    login = True
  elif username not in valid_user and password in valid_password:
    print("The username you have entered is incorrect.\nPlease try entering your username and password carefully again:\n")
    login = False
  elif username in valid_user and password not in valid_password:
    print("The password you have entered is incorrect.\nPlease try entering your username and password carefully again:\n")
    login = False
  elif username not in valid_user and password not in valid_password:
    print("The username and password you have entered is incorrect.\nPlease try entering your username and password carefully again:\n")
    login = False
  
# define the menu to use in the program
# define the menu for admin seperate
# print menu for user to choose an option
# create variable for option to use in program loops
# return option
def menu():
  print("\nPlease select one of the following options\nby entering the given character eg: 'r'\n")
  print("[r] r = register a new user")
  print("[a] a = add a task")
  print("[va] va = view all tasks")
  print("[vm] vm = view my tasks")
  print("[gr] gr = generate reports")
  print("[e] e = exit\n")
  option = input("Enter your option here: ")
  return option

def menu1(username):
  username = "admin"
  print("\nPlease select one of the following options\nby entering the given character eg: 'r'\n")
  print("[r] r = register a new user")
  print("[a] a = add a task")
  print("[va] va = view all tasks")
  print("[vm] vm = view my tasks")
  print("[ds] ds = display stastistics")
  print("[gr] gr = generate reports")
  print("[e] e = exit\n")
  option = input("Enter your option here: ")
  return option

# menu for admin to return to main menu or continue
# to add new users
# using if statements to control flow
# use else to pass
def menu_admin():
  print('''
  Would you like to continue adding a new user
  or return to the main menu?\n
  [c] c = continue
  [mm] mm = main menu\n''')
  action = input("Enter your choice here: ").lower()
  if action == "c":
    reg_user("r")
  else:
    pass
  
# define task menu for loading new tasks
# use if and else statements to navigate options
# use elif no to pass
def task_menu():
  cont_task = input("Do you want to load another task? yes/no:\n").lower()
  if cont_task == "yes":
    option = "a"
    add_task(option)
  elif cont_task == "no":
    pass
  else:
    print('''You did not make a valid selection.
    Please try again''')
    task_menu()

# define editing task menu
# use if and elif statements for different 
# options to be edited
# using else statements to notify user of invalid options
def task_edit_menu():
  edit = int(input('''
  Select a specific task by entering the Task Number here,\nor enter "-1" to return to the main menu: '''))
  edit1 = str(edit)
  if edit == -1:
    menu()
  elif edit != -1:
    f = open("tasks.txt", "r", encoding='UTF-8')
    f_read = f.readlines()
    for i in f_read:
      user_task = i.split(', ')
      if username == user_task[1]:
        user_list1 = user_task
        user_index_number = user_list1.index(edit1)
        control = user_index_number + 6
        control2 = user_list1[control]
        if control2 == "Yes":
          print('''
          This task is complete. You can not edit it.''')
          task_edit_menu()
        else:
          print('''
          [e] e = Edit Task
          [mt] mt = Mark the task as complete''')
          task_option = input("Enter your choice here: ").lower()
          if task_option == "e":
            print('''
            Make a selection from the list below:
            [u] u = Change the username assigned to this task
            [d] d = Change the due date for this task''')
            ts_opt = input("Enter your selection here: ").lower()
            if ts_opt == "u":
              edit_user_name(edit1, user_list1)
              print("\nNew username assigned.\n")
              task_edit_menu()
            elif ts_opt == "d":
              edit_user_date(edit1, user_list1)
              print("\nDue Date changed succesfully.\n")
              task_edit_menu()
            else:
              print('''
              You did not make a valid selection. 
              Try again''')
              task_edit_menu()
          elif task_option == "mt":
            mark_as_complete(edit1, user_list1)
            print("\nTask succesfully marked as complete:\n")
            task_edit_menu()
          else:
            print('''
            You did not make a valid selection. 
            Try again''')
            task_edit_menu()
  else:
    print('''
    You did not make a valid selection. 
    Try again''')
    task_edit_menu()
    
  
# define editing the user name 
# getting user list1 from task edit menu
# getting index number from task_edit_menu
# adding 1 position for user name position
# get new username from user and title case it
# get old username from list
# using remove and insert to edit information
# using for loop to print out new information
def edit_user_name(edit1, user_list1):
  task_index = user_list1.index(edit1)
  user_index = task_index + 1
  new_user = input("Enter the new user that this tasks belongs to here:\n").title()
  old_user = user_list1[user_index]
  user_list1.remove(old_user)
  user_list1.insert(user_index, new_user)
  for line in user_list1:
    print(line)

# defining the user date edit method
# getting user list1 from task edit menu
# getting index number from task_edit_menu
# adding 5 position for date position
# get new date from user and title case it
# get old date from list
# using remove and insert to edit information
# using for loop to print out new information
# return to task_edit_menu
def edit_user_date(edit1, user_list1):
  task_index = user_list1.index(edit1)
  user_index = task_index + 5
  new_date = input('''Enter the new date that this task needs to be completed by, e.g: 10 Oct 2022:\n''').title()
  old_date = user_list1[user_index]
  user_list1.remove(old_date)
  user_list1.insert(user_index, new_date)
  for line in user_list1:
    print(line)

# defining mark as complete method
# getting user list1 from task edit menu
# setting task complete to Yes
# getting index number from task_edit_menu
# adding 6 position for complete position
# using pop to remove no status from list
# using insert to put new status in correct index position
# using for loop to print out new information
# return to task_edit_menu
def mark_as_complete(edit1, user_list1):
  task_complete = "Yes"
  task_index = user_list1.index(edit1)
  comp_index_position = task_index + 6
  user_list1.pop(comp_index_position)
  user_list1.insert(comp_index_position, task_complete)
  for line in user_list1:
    print(line)

# define registering a new user 
# use option as the value to activate function
# use if and elif statement to only allow
# admin to register new users
# set new_user as bool False
# use while loop to enter new user
# use if statement to not duplicate new user
# use if and elif statement to check password
# open file and add new user and password
def reg_user(option):
  option = "r"
  if username == "admin":
    print("\nRegister a new user: ")
    new_user = False
  elif username != "admin":
    print("\nOnly admin is allowed to register new users.\n")
    new_user = True
        
  while new_user == False:
    username_new = input("\nEnter new users username: ")
    user_file = open("user.txt", "r")
    user_f_read = user_file.read()
    if username_new in user_f_read:
      print("\nThis username all ready exist.\n")
      new_user = menu_admin()
    elif username_new not in user_file:
      password_new = input("\nEnter new users password: ")
      confirm_pw = input("Confirm new users password: ")
      user_file.close()
      if password_new == confirm_pw:
        new_user = True
      elif password_new != confirm_pw:
        print("\nThe passwords you have entered do not match.\nPlease try confirming your password again:\n")
        new_user = False
    if new_user == True:
      user_file = open("user.txt", "a")
      user_file.write("\n" + username_new + ", " + password_new)
      user_file.close()
      print("\nNew user loaded succesfully.")
      new_user = menu_admin()
  return option

# define add a task
# get user input on variable names to save tasks
# use date today to add today's date to start date
# set task complete to no for anitional status
# use with to open file 
# use write to add tasks to file
# return option and return to main menu
def add_task(option):
  option = "a"
  print("\nAdd a new task:\n")
  task_number = 2 
  if option == "a" :
    task_number +=1
  user_task = input("Enter the username that this task belongs to:\n")
  task_name = input("Enter the name of the task to be assigned to the user:\n")
  task_ass = input("Enter the description of the task being assigned to this user:\n")
  start_date = date.today()
  end_date = input("Enter the date that this task needs to be completed by,\ne.g: 10 Oct 2022:\n").title()
  task_complete = "No"
  with open("tasks.txt", "a") as task:
    task.write("\n" + str(task_number))
    task.write(", " + user_task)
    task.write(", " + task_name)
    task.write(", " + str(task_ass))
    task.write(", " + str(start_date))
    task.write(", " + str(end_date))
    task.write(", " + task_complete)
    print("\nTask loaded succesfully:\n")
    task_menu()
  return option

# define view all task with option
# open file and read file
# replace new line with comma 
# split at comma and close file
# lable list to use in zip function
# use the for loop to enumerate and zip
# lable list and user task line by the
# length of the task line
# use the format function and space the 
# items with the number of spaces required
# to print in a user friendly manner
# return optiona and call main menu
def view_all(option):
  option = "va"
  f = open("tasks.txt", "r")
  task_list = f.read()
  task_list = task_list.replace("\n", ", ")
  task_line = task_list.split(", ")
  f.close()
  lable_list = ['Task Number', 'Username:', 'Task Name:', 'Task Description:', 'Date Assigned:', 'Due Date:', 'Task Completed?']
  for a, b in zip(lable_list*(len(task_line)), task_line):
    print(f'{a:<20} {b}')

#  for i, (a, b) in enumerate(zip((lable_list*(len(task_line))), task_line)):
 #   print(f'{i:<8} {a:<20} {b}')
  return option
  
# define view mine with option
# open file and read license
# lable list - defined
# use a for loop to split the file into a list
# use if statement to compare username to 
# username in task file
# use a for loop enumerate and zip to add numbers and 
# print out numbers lable and task 
# use format to space printed items 
# in user friendly manner
# call edit menu to give user option to edit tasks
# return option and main menu
def view_mine(option):
  option == "vm"
  f = open ("tasks.txt", "r", encoding='UTF-8')
  f_read =  f.readlines()
  user_list2 = []
  lable_list = ['Task Number', 'Username:', 'Task Name:', 'Task Description: ', 'Date Assigned: ', 'Due Date: ', 'Task Completed? ']
  for i in f_read:
    user_task = i.split(', ')
    if username == user_task[1]:
      user_list1 = user_task
      user_list2.append(user_list1)
      for a, b in zip(lable_list*(len(user_list1)), user_list1):
        print(f'{a:<20} {b}')
  task_edit_menu()
  return option

# define stats display 
# set option for function
# open user and tasks text files in read mode 
# set counter for user and tasks respectively
# use a for loop to loop through the lines of the files 
# use a if statement to run count for new lines 
# use print function to display results
# close files and return option
def stats_display(option):
  option == "ds"
  user_stats = open("user.txt", "r")
  task_stats = open("tasks.txt", "r")          
  count_user = 0
  count_task = 0
  for line in user_stats:
    if line != "\n":
      count_user += 1
  for line in task_stats:
    if line != "\n":
      count_task += 1
  with open("user_overview.txt", "w") as user_overview:
    user_overview.write("The total number of users registered is " + str(count_user) + ".")
  with open("task_overview.txt", "w") as task_overview:
    task_overview.write("The total number of tasks is " + str(count_task) + ".\n")
  with open("user_overview.txt", "r") as user_view:
    overview_rd = user_view.readlines()
    print("\n", overview_rd[0])
  with open("task_overview.txt", "r") as task_view:
    taskview_rd = task_view.readlines()
    print("\n", taskview_rd[0])    
  
  user_stats.close()
  task_stats.close()
  return option

# define gen reports with option
# use the with function to open the files 
# set count variables to keep record of items in files
# write info to files 
def gen_report(option):
  option = "gr"
  current_user_tasks = []
  user_overdue = []
  user_task_qty = []
  overdue = []
  
  with open("user_overview.txt", "w+") as user_over:
    count_user = 0
    with open("user.txt", "r") as user_view:
      for line in user_view:
        if line != "\n":
          count_user += 1 
    with open("tasks.txt", "r") as task_view:
      task_read = task_view.read()
      user_tsk_split = task_read.split(", ")
      for user in user_tsk_split:
        if username == user[0]:
          current_user_tasks.append(user)
      task_stats = open("tasks.txt", "r")
      count_task = 0
      for line in task_stats:
        if line != "\n":
          count_task += 1
      with open("user_overview.txt", "w+") as user_over:    
        user_over.write("\nUser Reports:\n")
        user_over.write("The total number of users registered is " + str(count_user) + ".\n")
        user_over.write("The total number of tasks is " + str(count_task) + ".\n")
        for user_qty in current_user_tasks:
          user_tsk_qty = user_qty
          user_task_qty.append(user_task_qty) 
          user_tsk_sum = user_tsk_qty / 6 
          user_over.write("The total number of tasks for " + username + " is " + str(user_tsk_sum) + ".\n")
          user_per_ass = (user_tsk_sum / count_task) * 100
          user_over.write(str(user_per_ass) + " percent of the total tasks have been assigned to " + username + ".\n")
          user_comp_no = current_user_tasks.count("No")
          user_comp_yes = current_user_tasks.count("Yes")
          user_per_comp = (user_comp_yes / user_tsk_sum ) * 100
          user_per_incomp = (user_comp_no / user_tsk_sum) * 100
          user_over.write(user_per_comp + " percent of the tasks assigned to " + username + " is completed.")
          user_over.write(user_per_incomp + " percent of the tasks assigned to " + username + " must still be completed.")
      for date in current_user_tasks:
        if date < date.today():
          overdue.append(date)  
      for i in overdue:
        overdue_qty = i
        over_pers = (overdue_qty / user_tsk_sum) * 100
        user_over.write(str(over_pers + " percent of uncompleted tasks for " + username + " are overdue.\n"))
  with open("task_overview.txt", "w+") as task_over:
    task_over.write("Task Reports:\n")
    task_over.write("The total number of tasks generated so far is " + str(count_task) + ".\n")
    comp_no = task_read.count("No")
    comp_yes = task_read.count("Yes")
    task_over.write("The total number of tasks that are completed is " + str(comp_yes) + ".\n")
    task_over.write("The total number of tasks that are uncompleted is " + str(comp_no) + ".\n" )
    overdue_sum = sum(overdue)+1
    overdue_qty = (count_task / overdue_sum)
    task_over.write("The total number of uncompleted tasks that are overdue is " + str(overdue_qty) + ".\n")
    incomp_pers = (comp_no / (count_task)) * 100
    task_over.write(str(incomp_pers) + " percent of tasks are incomplete.\n")
    over_pers = (overdue_qty / (count_task)) * 100
    task_over.write(str(over_pers) + " percent of tasks are overdue.\n")
  user_report = open("user_overview.txt", "r").read()
  task_report = open("task_overview.txt", "r").read()
  print(user_report)
  print(task_report)
      
  

if username == "admin":
  m = menu1(username)
elif username != "admin":
  m = menu()  
option = m
    

while option != "e":
  if option == "r":
    reg_user(option) 
  elif option == "a":
    add_task(option) 
  elif option == "va":
    view_all(option)
  elif option == "vm":
    view_mine(option)  
  elif option == "ds":
    stats_display(option) 
  elif option == "gr":
    gen_report(option)        
  else:
    print("\nYou did not choose a valid option:\n")
  if username == "admin":
    m = menu1(username)
  elif username != "admin":
    m = menu()  
  option = m
   
    
print("Good bye!")

# Refering:
# https://developers.google.com/edu/python/lists
# https://www.dropbox.com/home/Janina%20Haffner-110999/Introduction%20to%20Programming/Task%2020?preview=SE+L1T20+-+Capstone+Project+III+-+Files.pdf
# https://www.youtube.com/watch?v=63nw00JqHo0
# call with code reviewer James Dean. Assisted me in undersanding how to make my login work by using in function instead of equals opperator.
# https://www.freecodecamp.org/news/the-zip-function-in-python-explained-with-examples/
